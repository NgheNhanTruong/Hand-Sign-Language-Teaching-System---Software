# Hand_sign Detection Tensorflow API > 2022-07-17 6:23pm
https://universe.roboflow.com/object-detection/hand_sign-detection-tensorflow-api

Provided by Roboflow
License: CC BY 4.0

